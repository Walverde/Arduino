/* ------------------------------------------------
Estrutura b�sica de um programa em C
--------------------------------------------------- */
char neg ( char a)
{
     return ~a; // inverte todos os bits
}
/* ------------- Fun��o Principal ----------------- */
void main ()
{
 char temp ; // declara��o de vari�vel
 TRISD = 0x00 ; // porta D como sa�da
 PORTD = 0x0F ; // padrao de cada pino : 0 ou 1
 while(1) // looping infinito
 {
    Delay_ms(100);  // espera em ms
    PORTD = neg(PORTD); // chama a funcao neg ()
 }
}
